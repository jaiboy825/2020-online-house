window.onload = function () {
    $.getJSON("./resources/store.json",
        function (data) {
            for (let i = 0; i < data.length; i++) {
                console.log(data[i]);

                item(data[i]);
            }

        }
    );
}

function item(data) {
    let form =
        `
    <div class="productCase">
        <img src="/Publishing/resources/상품사진/${data.photo}" alt="">  
        <div class="productInfo">
        ${data.brand} <br> 
        ${data.product_name} <br>
        ${data.price}
        </div>                  
     </div>
    `;

    $(".productContainer").append(form);
}