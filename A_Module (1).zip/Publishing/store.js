window.addEventListener("load", () => {
    $.getJSON("./resources/store.json", (data) => {
        let app = new App(data);
    });
});

class App {
    constructor(product) {
        this.product = product;
        this.main();
    }

    main() {
        this.product.forEach((x) => {
            let item = this.item(x);
            document.querySelector(".productContainer").appendChild(item);
            $(item).draggable({
                containment: ".StoreCenter",
                helper: "clone",
                cursor: "pointer",
                cancel: ".productInfo",
                revert: true,

                drag(){
                    $(".Goal").css("border","3px dotted red");
                },
                stop(){
                    $(".Goal").css("border","3px dotted black");
                }
            });
        });
    }

    item(x) {
        let div = document.createElement("div");
        div.classList.add("pd");
        div.innerHTML = `
            <div class="productCase">
                <img src="/Publishing/resources/상품사진/${x.photo}" alt="">  
                <div class="productInfo">
                    <h4>${x.brand} </h4> 
                    ${x.product_name} <br>
                    ${x.price}
                </div>                  
            </div>
        `;
        return div;
    }


    
}