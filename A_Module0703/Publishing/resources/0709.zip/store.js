window.addEventListener("load", ()=>{
    $.getJSON("./resources/store.json", (data)=>{
        let app = new App(data);
        data.forEach((x) => {
            x.cnt = 1;
        });
    })
});

function unComma(str){
    n = parseInt(str.replace(/,/g, ""));
    return n;
}

class App{
    constructor(product){
        this.product = product;
        this.productList = [];
        this.main();
    }
    main(){
        this.product.forEach((x)=>{
            let item = this.item(x);
            document.querySelector(".productContainer").appendChild(item);
            $(item).draggable({
                containment : ".storeCenter",
                helper : "Clone",
                cursor : "pointer",
                cancel : ".productInfo",
                revert : true,
                drag(){

                },   
                stop(){

                }
            });
            $(".Goal").droppable({
                accept : ".pd",
                drop : (e, ui)=>{
                    let id = ui.draggable[0].dataset.id;
                    let item = this.product[id - 1];
                    let find = this.productList.find(function (f){
                        return f.id == item.id;
                    });
                    if(find === undefined) this.dropItem(item);
                    else alert("이미 장바구니에 담긴 상품입니다")
                }   
            });
        });
    }
    item(item){
        let div = document.createElement("div");
        div.dataset.id = item.id;
        div.classList.add("pd");
        div.innerHTML = ``;
        return div;
    }
    dropItem(item){
        this.productList.push(item);
        let div = document.createElement("div");
        div.classList.add("cd");
        div.innerHTML =``;
        document.querySelector(".carts").appendChild(div);
    }
}