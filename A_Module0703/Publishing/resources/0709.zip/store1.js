window.addEventListener("load", ()=>{
    $.getJSON("./resources/store.json", (data)=>{
        let app = new App(data);
        data.forEach((x) => {
            x.cnt = 1;
        });
    });
});

function unComma(str){
    n = parseInt(str.replace(/,/g,""));
    return n;
}
class App{
    constructor(product){
        this.product = product;
        this.productList = [];
        this.main();
    }
    main(){

    }
    item(item){

    }
    dropItem(item){
        
    }
}