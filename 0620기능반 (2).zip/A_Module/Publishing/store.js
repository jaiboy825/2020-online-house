window.onload = function() {
    $.getJSON("./resources/store.json",
        function (data) {
            for(let i = 0; i < data.length; i++) {
                console.log(data[i]);

                item(data[i]);
            }
            
        }
    );
}

function item(data) {
    let form =  
    `
    ${data.photo}
    `;

    $(".center").append(form);
}